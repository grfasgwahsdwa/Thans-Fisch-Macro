Run the program. When you access the settings, change the UUID key to "COMMERCIAL" to be able to use.

This program was made by thansar62